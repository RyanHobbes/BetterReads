
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="include/style.css">
</head>
<body>
<header>
        <div class="logo">
            <a href="index.php"><img src="images/logo.png" alt="logo"></a>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="storefront.php">FRIENDS</a></li>
                <li><a href="about.php">TBR LIST</a></li>
                <li><a href="contact.php">My REVIEWS</a></li>
               
            </ul>
        </nav>
    </header>

</body>
</html>